<?php

class Connection{
    public $ticket;
    public $host;
    public $port;    
    private $curl_con_timeout = 10;
    private $curl_timeout = 10;
    
    function __construct($host, $port)
    {
        $url = "http://" . $host . ":" . $port;        
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->curl_con_timeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->curl_timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        $response = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if($http_status == "200")
        {
            $response = json_decode($response);            
            if($response->bytengine == "welcome")
            {
                $this->host = $host;
                $this->port = $port;
            }
            else
            {
                echo "connection error";
            }
        }
        else throw new Exception($bytengine_response);
    }
    
    function login($username, $password, $database)
    {
        $command = "login -u='$username' -p='$password' -d='$database'";
        $post_data = "command=". urlencode($command);
        
        $url = "http://" . $this->host . ":" . $this->port . "/bfs";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->curl_con_timeout);        
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->curl_timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        
        $response = curl_exec($ch);        
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if($http_status == "200")
        {
            $response = json_decode($response);            
            if($response->status == "ok")
            {
                $this->ticket = $response->data->ticket;
            }
            else
            {
                echo $response->msg;
            }
        }
        else throw new Exception($response);
    }
    
    function runcommand($commandstring, $returnstring=true)
    {
        $post_data = "command=". urlencode($commandstring) ."&ticket=" .$this->ticket;
        
        $url = "http://" . $this->host . ":" . $this->port . "/bfs";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->curl_con_timeout);        
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->curl_timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        
        $response_raw = curl_exec($ch);        
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if($http_status == "200")
        {
            $response = json_decode($response_raw);            
            if($returnstring) return $response_raw;
            else return $response;
        }
        else throw new Exception($response);
    }
    
    function uploadfile($localfilepath, $remotefilepath)
    {
        $post_data = array("command"=>"upload ".$remotefilepath,
                           "ticket"=>$this->ticket,
                           "file"=>"@".$localfilepath);
        $url = "http://" . $this->host . ":" . $this->port . "/bfs/upload";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->curl_con_timeout);        
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        
        $response_raw = curl_exec($ch);        
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $response = json_decode($response_raw);            
        
        if($http_status == "200")
        {
            $response = json_decode($response_raw);            
            if($returnstring) return $response_raw;
            else return $response;
        }
        else throw new Exception($response);
    }
}

?>